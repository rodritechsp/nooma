import React from 'react';
import { Link } from 'react-router-dom';
import { Track } from '../types';
import { useAudio } from '../context/NoomaAudioContext';
import { getGoogleDriveDirectLink } from '../utils';

interface SectionRowProps {
    title: string;
    items: Track[];
}

const SectionRow: React.FC<SectionRowProps> = ({ title, items }) => {
    const { playTrack, currentTrack, isPlaying } = useAudio();

    const handlePlayClick = (e: React.MouseEvent, item: Track) => {
        e.preventDefault();
        playTrack(item);
    };

    return (
        <section className="mt-8 sm:mt-10 pl-4 sm:pl-5">
            <div className="flex items-center justify-between pr-4 sm:pr-5 mb-3 sm:mb-4">
                <h3 className="text-white text-base sm:text-lg font-bold tracking-tight">{title}</h3>
                <button className="text-text-muted text-xs sm:text-sm hover:text-primary transition-colors touch-target">Ver Mais</button>
            </div>
            <div className="relative">
                <div className="flex overflow-x-auto no-scrollbar gap-3 sm:gap-4 md:gap-5 pb-4 pr-4 sm:pr-5 snap-x snap-mandatory scroll-smooth">
                    {items.map(item => {
                        const isCurrent = currentTrack?.id === item.id;
                        return (
                            <div
                                key={item.id}
                                className="flex-shrink-0 w-36 sm:w-40 md:w-44 snap-start group cursor-pointer"
                                onClick={(e) => handlePlayClick(e, item)}
                            >
                                <div className="w-full aspect-square rounded-2xl overflow-hidden relative mb-2.5 sm:mb-3 bg-surface-dark shadow-lg">
                                    <img
                                        className={`w-full h-full object-cover transition-all duration-500 ${isCurrent && isPlaying ? 'scale-110 opacity-60' : 'opacity-80 group-hover:opacity-100 group-hover:scale-110'}`}
                                        src={getGoogleDriveDirectLink(item.img)}
                                        alt={item.title}
                                    />
                                    <div className="absolute bottom-2 right-2 bg-black/40 backdrop-blur-sm px-2 py-0.5 rounded text-[10px] font-bold text-white">{item.duration}</div>
                                    <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${isCurrent && isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                                        <div className="bg-primary/90 text-background-dark rounded-full p-2 sm:p-2.5">
                                            <span className="material-symbols-outlined text-[18px] sm:text-[20px] fill-1">
                                                {isCurrent && isPlaying ? 'pause' : 'play_arrow'}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <h4 className={`text-xs sm:text-sm font-semibold truncate ${isCurrent ? 'text-primary' : 'text-white'}`}>{item.title}</h4>
                                <p className="text-text-muted text-[11px] sm:text-xs truncate mt-0.5">{item.subtitle}</p>
                            </div>
                        );
                    })}
                </div>
            </div>
        </section>
    );
};

export default SectionRow;