import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const NavLinkItem = ({ to, icon, label, exact = false }: { to: string, icon: string, label: string, exact?: boolean }) => {
    const location = useLocation();
    const isActive = exact
        ? location.pathname === to
        : location.pathname.startsWith(to) && (to !== "/" || location.pathname === "/");

    return (
        <Link to={to} className={`flex flex-col items-center gap-0.5 sm:gap-1 p-2 sm:p-2.5 group touch-target`}>
            <div className={`transition-all p-1 sm:p-1.5 rounded-full ${isActive ? 'text-primary active-nav-glow' : 'text-text-muted group-hover:text-white'}`}>
                <span className={`material-symbols-outlined ${isActive ? 'fill-1' : ''}`} style={{ fontSize: '26px' }}>
                    {icon}
                </span>
            </div>
            <span className={`text-[10px] sm:text-xs font-medium transition-colors ${isActive ? 'text-primary' : 'text-text-muted group-hover:text-white'}`}>
                {label}
            </span>
        </Link>
    );
};

const BottomNav: React.FC = () => {
    return (
        <nav className="fixed bottom-0 left-0 right-0 z-50 glass-nav h-20 sm:h-[84px] max-w-md mx-auto">
            <div className="flex items-center justify-around h-full pb-3 sm:pb-4 px-1 sm:px-2">
                <NavLinkItem to="/" icon="home" label="Início" exact={true} />
                <NavLinkItem to="/explore" icon="explore" label="Explorar" />
                <NavLinkItem to="/library" icon="library_music" label="Biblioteca" />
                <NavLinkItem to="/premium" icon="workspace_premium" label="Premium" />
            </div>
        </nav>
    );
};

export default BottomNav;