import React from 'react';
import { useLocation, Outlet } from 'react-router-dom';
import BottomNav from './BottomNav';
import MiniPlayer from './MiniPlayer';

const Layout: React.FC = () => {
    const location = useLocation();
    
    // Hide BottomNav and MiniPlayer on Player and Premium pages
    const isPlayerPage = location.pathname === '/player';
    const isPremiumPage = location.pathname === '/premium';
    const showNav = !isPlayerPage && !isPremiumPage;

    return (
        <div className="h-full w-full flex flex-col">
            <Outlet />
            {showNav && <MiniPlayer />}
            {showNav && <BottomNav />}
        </div>
    );
};

export default Layout;