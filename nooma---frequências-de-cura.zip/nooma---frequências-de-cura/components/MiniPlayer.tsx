import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAudio } from '../context/NoomaAudioContext';
import { getGoogleDriveDirectLink, formatTime } from '../utils';

const MiniPlayer: React.FC = () => {
    const navigate = useNavigate();
    const { currentTrack, isPlaying, togglePlay, duration, currentTime, progress } = useAudio();

    if (!currentTrack) return null;

    const timeLeft = duration - currentTime;

    return (
        <div className="fixed bottom-[84px] sm:bottom-[88px] left-0 right-0 px-3 sm:px-4 z-40 max-w-md mx-auto pointer-events-none">
            <div
                onClick={() => navigate('/player')}
                className="bg-surface-dark rounded-xl shadow-[0_8px_24px_rgba(0,0,0,0.4)] border-t border-white/5 p-2 sm:p-2.5 pr-3 sm:pr-4 flex items-center gap-2.5 sm:gap-3 w-full pointer-events-auto cursor-pointer group hover:bg-[#1f3546] transition-colors overflow-hidden relative"
            >
                {/* Progress Bar background */}
                <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-white/5">
                    <div
                        className="h-full bg-primary shadow-[0_0_8px_rgba(142,225,210,0.6)] transition-all duration-300 ease-linear"
                        style={{ width: `${progress}%` }}
                    ></div>
                </div>

                <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-lg overflow-hidden shrink-0">
                    <img className="h-full w-full object-cover" src={getGoogleDriveDirectLink(currentTrack.img)} alt="Album Art" />
                </div>

                <div className="flex-1 min-w-0 flex flex-col justify-center">
                    <div className="flex items-center gap-1.5 sm:gap-2">
                        <span className="text-white text-sm sm:text-base font-bold truncate">{currentTrack.title}</span>
                        {isPlaying && <span className="text-primary text-[9px] sm:text-[10px] border border-primary/30 px-1 rounded animate-pulse shrink-0">Tocando</span>}
                    </div>
                    <p className="text-text-muted text-xs sm:text-sm truncate">
                        {currentTime > 0 ? formatTime(timeLeft) + ' restantes' : currentTrack.subtitle}
                    </p>
                </div>

                <div className="flex items-center gap-2 sm:gap-3">
                    <button className="text-text-muted hover:text-white transition-colors touch-target" onClick={(e) => { e.stopPropagation(); /* Logic for prev */ }} aria-label="Anterior">
                        <span className="material-symbols-outlined" style={{ fontSize: '22px' }}>skip_previous</span>
                    </button>
                    <button
                        className="bg-primary text-background-dark rounded-full p-1.5 sm:p-2 hover:scale-105 transition-transform touch-target"
                        onClick={(e) => { e.stopPropagation(); togglePlay(); }}
                        aria-label={isPlaying ? 'Pausar' : 'Tocar'}
                    >
                        <span className="material-symbols-outlined fill-1" style={{ fontSize: '20px' }}>
                            {isPlaying ? 'pause' : 'play_arrow'}
                        </span>
                    </button>
                    <button className="text-text-muted hover:text-white transition-colors touch-target" onClick={(e) => { e.stopPropagation(); /* Logic for next */ }} aria-label="Próxima">
                        <span className="material-symbols-outlined" style={{ fontSize: '22px' }}>skip_next</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default MiniPlayer;