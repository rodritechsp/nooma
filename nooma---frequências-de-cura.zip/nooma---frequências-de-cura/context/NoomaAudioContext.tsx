import React, { createContext, useContext, useState, useRef, useEffect } from 'react';
import { Track, CategoryData, AudioContextType } from '../types';
import { fetchDriveContent } from '../utils/driveService';
import { getGoogleDriveDirectLink } from '../utils';

const AudioContext = createContext<AudioContextType | undefined>(undefined);

export const AudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [categories, setCategories] = useState<CategoryData[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    const audioRef = useRef<HTMLAudioElement | null>(null);

    // Fetch Drive Content on Mount
    useEffect(() => {
        const loadContent = async () => {
            setIsLoading(true);
            try {
                if (import.meta.env.VITE_GOOGLE_API_KEY && import.meta.env.VITE_ROOT_FOLDER_ID) {
                    const data = await fetchDriveContent();
                    setCategories(data);
                } else {
                    console.log("API Keys missing, skipping fetch");
                }
            } catch (err) {
                console.error("Failed to load drive content", err);
            } finally {
                setIsLoading(false);
            }
        };

        loadContent();
    }, []);

    // Initialize Audio Element
    useEffect(() => {
        audioRef.current = new Audio();
        audioRef.current.preload = 'metadata';

        const audio = audioRef.current;

        const updateProgress = () => {
            if (audio.duration) {
                setCurrentTime(audio.currentTime);
                setDuration(audio.duration);
                setProgress((audio.currentTime / audio.duration) * 100);
            }
        };

        const handleEnded = () => {
            setIsPlaying(false);
            setProgress(0);
            playNext(); // Auto-play next
        };

        audio.addEventListener('timeupdate', updateProgress);
        audio.addEventListener('loadedmetadata', updateProgress);
        audio.addEventListener('ended', handleEnded);

        return () => {
            audio.removeEventListener('timeupdate', updateProgress);
            audio.removeEventListener('loadedmetadata', updateProgress);
            audio.removeEventListener('ended', handleEnded);
            audio.pause();
        };
    }, []);

    const playTrack = async (track: Track) => {
        if (!audioRef.current) return;

        // If clicking the same track, toggle play
        if (currentTrack?.id === track.id) {
            togglePlay();
            return;
        }

        setCurrentTrack(track);

        // Process URL (Cloudinary is already full URL, but we pass through helper just in case)
        const src = getGoogleDriveDirectLink(track.audioUrl);
        audioRef.current.src = src;

        try {
            console.log(`🎵 Tocando: ${track.title}`);
            await audioRef.current.play();
            setIsPlaying(true);
        } catch (err) {
            console.error("❌ Erro ao tocar áudio:", err);
            setIsPlaying(false);
        }
    };

    const togglePlay = () => {
        if (!audioRef.current || !currentTrack) return;

        if (isPlaying) {
            audioRef.current.pause();
            setIsPlaying(false);
        } else {
            audioRef.current.play().catch(e => console.error("Play error:", e));
            setIsPlaying(true);
        }
    };

    const seek = (time: number) => {
        if (!audioRef.current) return;
        audioRef.current.currentTime = time;
        setCurrentTime(time);
        setProgress((time / duration) * 100);
    };

    // Helper to find current track position
    const getTrackIndex = () => {
        if (!currentTrack) return null;
        for (let cat of categories) {
            const idx = cat.items.findIndex(t => t.id === currentTrack.id);
            if (idx !== -1) return { cat, idx, items: cat.items };
        }
        return null;
    };

    const playNext = () => {
        const info = getTrackIndex();
        if (info) {
            const nextIdx = info.idx + 1;
            if (nextIdx < info.items.length) {
                playTrack(info.items[nextIdx]);
            } else {
                // Loop to first? Or stop. Let's loop for now or stop.
                // For sleep app, maybe loop category?
                // playTrack(info.items[0]); 
                setIsPlaying(false);
            }
        }
    };

    const playPrev = () => {
        const info = getTrackIndex();
        if (info) {
            const prevIdx = info.idx - 1;
            if (prevIdx >= 0) {
                playTrack(info.items[prevIdx]);
            } else {
                seek(0); // Restart current if first
            }
        }
    };

    return (
        <AudioContext.Provider value={{
            currentTrack,
            isPlaying,
            progress,
            currentTime,
            duration,
            categories,
            isLoading,
            playTrack,
            togglePlay,
            seek,
            playNext,
            playPrev
        }}>
            {children}
        </AudioContext.Provider>
    );
};

export const useAudio = () => {
    const context = useContext(AudioContext);
    if (!context) {
        throw new Error('useAudio must be used within an AudioProvider');
    }
    return context;
};
