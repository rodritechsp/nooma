import { Track, CategoryData } from '../types';

const API_KEY = import.meta.env.VITE_GOOGLE_API_KEY;
const ROOT_FOLDER_ID = import.meta.env.VITE_ROOT_FOLDER_ID;
const BASE_URL = 'https://www.googleapis.com/drive/v3/files';

// Configuração do Cloudinary
const CLOUDINARY_CLOUD_NAME = 'dqwuovncv';
const CLOUDINARY_BASE_URL = `https://res.cloudinary.com/${CLOUDINARY_CLOUD_NAME}/video/upload`;

interface DriveFile {
    id: string;
    name: string;
    mimeType: string;
    webViewLink?: string;
    webContentLink?: string;
    thumbnailLink?: string;
}

// Mapeamento MANUAL (Override) de URLCloudinary
// Use isso quando o nome gerado automaticamente não bater com o do Cloudinary
const CLOUDINARY_URLS: Record<string, string> = {
    // Exemplo: 'Nome_No_Drive.mp3' : 'URL_Completa_Do_Cloudinary'
    'binaural-beats-256Hz-25Hz-30min.mp3': 'https://res.cloudinary.com/dqwuovncv/video/upload/v1768435311/binaural-beats-256Hz-25Hz-30min_xzxrft.mp3',
    'binaural-beats-200Hz-10Hz-30min.mp3': 'https://res.cloudinary.com/dqwuovncv/video/upload/v1768435969/binaural-beats-200Hz-10Hz-30min_btiehl.mp3',
};

/**
 * Fetches the application structure: Categories (folders) and Tracks (files)
 */
export const fetchDriveContent = async (): Promise<CategoryData[]> => {
    if (!API_KEY || !ROOT_FOLDER_ID) {
        console.warn("❌ Google Drive API Key or Root Folder ID is missing.");
        return [];
    }

    try {
        // 1. Fetch Categories (Subfolders of Root)
        const categories = await fetchSubfolders(ROOT_FOLDER_ID);

        if (categories.length === 0) {
            console.warn("⚠️ Nenhuma subpasta encontrada na pasta raiz!");
        }

        // 2. Fetch Tracks for each Category
        const content = await Promise.all(categories.map(async (cat) => {
            const tracks = await fetchAudioFiles(cat.id, cat.name);
            return {
                id: cat.id,
                title: cat.name.replace(/^\d+_/, '').replace(/_/g, ' '),
                items: tracks
            } as CategoryData;
        }));

        console.log("-----------------------------------");
        console.log("✅ CARREGAMENTO CONCLUÍDO");
        console.log(`📊 Categorias: ${content.length}`);
        console.log(`🎵 Total Tracks: ${content.reduce((acc, c) => acc + c.items.length, 0)}`);
        console.log("-----------------------------------");
        return content;
    } catch (error) {
        console.error("❌ Erro ao buscar conteúdo do Drive:", error);
        return [];
    }
};

const fetchSubfolders = async (parentId: string): Promise<DriveFile[]> => {
    const query = `'${parentId}' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
    return fetchDriveFiles(query);
};

const fetchAudioFiles = async (parentId: string, categoryName: string): Promise<Track[]> => {
    const query = `'${parentId}' in parents and (mimeType contains 'audio/' or name contains '.mp3') and trashed = false`;
    const files = await fetchDriveFiles(query);
    return files.map(file => mapDriveFileToTrack(file, categoryName));
};

const fetchDriveFiles = async (query: string): Promise<DriveFile[]> => {
    const url = `${BASE_URL}?q=${encodeURIComponent(query)}&key=${API_KEY}&fields=files(id, name, mimeType, webContentLink, thumbnailLink)&pageSize=100`;

    const response = await fetch(url);
    if (!response.ok) {
        const errorText = await response.text();
        console.error(`❌ Drive API Error (${response.status}):`, errorText);
        throw new Error(`Drive API Error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.files || [];
};

const mapDriveFileToTrack = (file: DriveFile, category: string): Track => {
    const nameWithoutExt = file.name.replace(/\.[^/.]+$/, "");
    const hzMatch = nameWithoutExt.match(/(\d+)Hz/i);
    const hz = hzMatch ? hzMatch[0] : undefined;

    // 1. TENTA MAPA MANUAL PRIMEIRO
    let audioUrl = CLOUDINARY_URLS[file.name] || CLOUDINARY_URLS[nameWithoutExt];
    let method = "MANUAL";

    // 2. SE NÃO TIVER NO MAPA, GERA O AUTOMÁTICO
    if (!audioUrl) {
        const sanitizedName = file.name.replace(/\s+/g, '_');
        audioUrl = `${CLOUDINARY_BASE_URL}/${sanitizedName}`;
        method = "AUTO";
    }

    console.groupCollapsed(`🎵 Configurando: ${file.name}`);
    console.log(`   📂 Categoria: ${category}`);
    console.log(`   ⚙️ Método: ${method}`);
    console.log(`   🔗 URL: ${audioUrl}`);
    console.groupEnd();

    return {
        id: file.id,
        title: nameWithoutExt,
        subtitle: category.replace(/^\d+_/, '').replace(/_/g, ' '),
        img: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?auto=format&fit=crop&q=80&w=500',
        duration: '0:00',
        category: category,
        hz: hz,
        audioUrl: audioUrl,
        driveId: file.id,
        mimeType: file.mimeType
    };
};
