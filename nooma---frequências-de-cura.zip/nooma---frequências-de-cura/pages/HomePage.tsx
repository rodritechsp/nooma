import React from 'react';
import { Link } from 'react-router-dom';
import SectionRow from '../components/SectionRow';
import { FREQUENCIES, FEATURED_TRACK } from '../constants';
import { useAudio } from '../context/NoomaAudioContext';
import { getGoogleDriveDirectLink } from '../utils';

const HomePage: React.FC = () => {
    const { playTrack, categories, isLoading } = useAudio();

    // Use a track from the first category as featured, or fallback to constant
    const featuredTrack = (categories.length > 0 && categories[0].items.length > 0)
        ? categories[0].items[0]
        : FEATURED_TRACK;

    return (
        <main className="flex-1 overflow-y-auto no-scrollbar pb-32 w-full max-w-md mx-auto relative z-10 bg-background-light dark:bg-background-dark">
            <header className="flex items-center justify-between p-6 pt-8 sticky top-0 z-20 bg-gradient-to-b from-background-dark/95 to-transparent backdrop-blur-[2px]">
                <div className="flex flex-col">
                    <span className="text-text-muted text-xs font-bold tracking-widest uppercase mb-0.5 opacity-80">Nooma</span>
                    <h1 className="text-white text-xl font-bold leading-tight tracking-tight">Boa noite, Alex</h1>
                </div>
                <div className="flex items-center gap-4">
                    <button className="relative text-white hover:text-primary transition-colors">
                        <span className="material-symbols-outlined" style={{ fontSize: '28px' }}>notifications</span>
                        <span className="absolute top-0 right-0 size-2.5 bg-primary rounded-full border-2 border-background-dark"></span>
                    </button>
                    <div className="size-10 rounded-full overflow-hidden border border-white/10 ring-2 ring-transparent hover:ring-primary/30 transition-all cursor-pointer">
                        <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBjICvPdx-CFTh6vrp45iV5NnSAoPTKvl33tFQVDLXo08HkaXXWY9NmGy3ipvRsNFq5_YN7yJ70hW7sQS_Qc4CsROMrvMM-WWhwHHJULmqPAXcQZZ7uKDizAtHIjF98O6nLc5a1d1av4LNNa89UPmXHI1EZ2LBfeug3BxLPRR9LI9MRC2KOXRO_rHuNUi2bXyjaNXVE0imJ0lElowmkLibr-0oASDx92-55_jy27RWHhQIP5vic0ygg8ynyzyQCK_saQEZrili-grI" alt="User" />
                    </div>
                </div>
            </header>

            <section className="px-5 mt-2">
                <div
                    onClick={() => playTrack(featuredTrack)}
                    className="block relative w-full rounded-[2rem] overflow-hidden group shadow-[0_8px_32px_rgba(0,0,0,0.3)] hover:shadow-[0_8px_40px_rgba(142,225,210,0.15)] transition-all duration-500 cursor-pointer"
                >
                    <div
                        className="absolute inset-0 bg-center bg-cover transition-transform duration-700 group-hover:scale-105"
                        style={{ backgroundImage: `url("${getGoogleDriveDirectLink(featuredTrack.img)}")` }}
                    >
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-background-dark via-background-dark/40 to-transparent opacity-90"></div>
                    <div className="relative z-10 p-6 flex flex-col justify-end h-full min-h-[320px]">
                        <div className="inline-flex items-center gap-2 mb-2">
                            <span className="px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-primary text-xs font-bold uppercase tracking-wider border border-primary/20">
                                {featuredTrack.category || "Destaque"}
                            </span>
                        </div>
                        <h2 className="text-3xl font-bold text-white mb-1 leading-tight tracking-tight">{featuredTrack.title}</h2>
                        <p className="text-text-muted text-sm font-medium mb-6">{featuredTrack.subtitle}</p>
                        <div className="flex items-center justify-between">
                            <div className="flex -space-x-3">
                                <div className="w-8 h-8 rounded-full border-2 border-[#192229] bg-slate-700 bg-cover" style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDG45A3pxkMF6v3Y-3pPF-KwbJT1oa4L0gZR8lu2SHUbSocYy63pwiaUIpw1x48f0A52OR79okwOHzc--s7_Ihff-YAkUu2F4lUaXIDrg87quPP-cKQrUuo9NXP8lCsoKjJ3Ix23pIlDomZ9KLfNaDV3msXHdJBOUzPkq5xJ4mVj9bmOTsVVce0c_FqaOQH83_kEGntt6h-3yGgW7TyYXjvkpQR9r8IyqnwtLPwD68dzoWfFWtPoxnTXFXSOwZxkg57tmIIsyTgh74")' }}></div>
                                <div className="w-8 h-8 rounded-full border-2 border-[#192229] bg-slate-600 bg-cover" style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuAlQIckwWYad408nQ5hPR04qaq2m1GmKR9ZIeRT_PDWIXl2IJt6_EKEISMEsnc2DWX1yR8iAgMBsj9g9QmGZ_Awk7TusUHxXP8tEQrz0W0SykeghbGBiXBvx-cItg28O4ZYG8aGQeKsik-u9OGrZSSSdNgwo9ZbmqmJwyaDdJk4zc6GlqT5NwHlU_Y7S7Ohll-3-upaCqzEA0IfRmh2mPul982lX_LB804XGyYd6dtBZn-VNF1henNfSPkayKP9V8IXPxW7x7NiuBY")' }}></div>
                                <div className="w-8 h-8 rounded-full border-2 border-[#192229] bg-slate-800 flex items-center justify-center text-[10px] text-white font-bold">+2k</div>
                            </div>
                            <button className="flex items-center gap-2 bg-primary hover:bg-primary-dark text-background-dark px-5 py-3 rounded-xl font-bold text-sm transition-all transform active:scale-95 shadow-[0_0_20px_rgba(142,225,210,0.3)]">
                                <span className="material-symbols-outlined text-[20px] fill-1">play_arrow</span>
                                <span>Ouvir Agora</span>
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            {isLoading ? (
                <div className="flex flex-col items-center justify-center py-20 opacity-50">
                    <span className="material-symbols-outlined animate-spin text-4xl text-primary mb-4">progress_activity</span>
                    <p className="text-text-muted text-sm animate-pulse">Sincronizando frequências...</p>
                </div>
            ) : (
                categories.map(category => (
                    <SectionRow
                        key={category.id}
                        title={category.title}
                        items={category.items}
                    />
                ))
            )}

            <div className="h-24 w-full"></div>

            {/* Ambient Background Elements */}
            <div className="fixed top-[-10%] left-[-10%] w-[50%] h-[40%] bg-primary/5 rounded-full blur-[120px] pointer-events-none z-0"></div>
            <div className="fixed bottom-[-10%] right-[-10%] w-[60%] h-[50%] bg-[#1A2D3C]/40 rounded-full blur-[100px] pointer-events-none z-0"></div>
        </main>
    );
};

export default HomePage;