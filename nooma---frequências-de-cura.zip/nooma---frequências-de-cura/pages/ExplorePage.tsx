import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAudio } from '../context/NoomaAudioContext';
import { getGoogleDriveDirectLink } from '../utils';

const ExplorePage: React.FC = () => {
    const navigate = useNavigate();
    const { playTrack, categories, isLoading, currentTrack, isPlaying } = useAudio();
    const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
    const [searchQuery, setSearchQuery] = useState('');

    // Flatten all tracks from all categories
    const allTracks = useMemo(() => {
        return categories.flatMap(cat => cat.items);
    }, [categories]);

    // Filter tracks based on selection and search
    const filteredTracks = useMemo(() => {
        let tracks = allTracks;

        if (selectedCategory) {
            tracks = categories.find(c => c.title === selectedCategory)?.items || [];
        }

        if (searchQuery) {
            const lowerQuery = searchQuery.toLowerCase();
            tracks = tracks.filter(t =>
                t.title.toLowerCase().includes(lowerQuery) ||
                t.subtitle?.toLowerCase().includes(lowerQuery)
            );
        }

        return tracks;
    }, [allTracks, categories, selectedCategory, searchQuery]);

    // Define recommended tracks (random shuffle or first few)
    const recommendedTracks = useMemo(() => {
        return [...allTracks].sort(() => 0.5 - Math.random()).slice(0, 5);
    }, [allTracks]);

    return (
        <div className="relative flex min-h-screen w-full flex-col overflow-x-hidden pb-24 bg-background-light dark:bg-background-dark max-w-md mx-auto">
            <header className="sticky top-0 z-20 flex items-center justify-between bg-background-dark/95 px-5 py-4 backdrop-blur-md border-b border-white/5">
                <button onClick={() => navigate(-1)} className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/5 transition-colors touch-target">
                    <span className="material-symbols-outlined text-2xl">arrow_back</span>
                </button>
                <h1 className="text-lg font-bold tracking-wide text-text-light">Explorar</h1>
                <button onClick={() => { setSelectedCategory(null); setSearchQuery(''); }} className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/5 transition-colors touch-target">
                    <span className="material-symbols-outlined text-2xl">refresh</span>
                </button>
            </header>

            <div className="px-5 pt-2 pb-4">
                <div className="glass-panel relative flex h-14 w-full items-center rounded-2xl transition-all focus-within:ring-1 focus-within:ring-primary/50">
                    <div className="flex h-full w-12 items-center justify-center pl-2">
                        <span className="material-symbols-outlined text-primary text-2xl">search</span>
                    </div>
                    <input
                        className="h-full w-full bg-transparent border-none text-base font-medium text-white placeholder:text-text-muted focus:ring-0 px-2 focus:outline-none"
                        placeholder="Buscar frequências..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
            </div>

            {/* Categories */}
            <div className="flex flex-col px-5 pt-2">
                <h3 className="mb-3 text-lg font-bold tracking-tight text-text-light">Categorias</h3>
                {isLoading ? (
                    <div className="flex justify-center py-4"><span className="material-symbols-outlined animate-spin text-primary">progress_activity</span></div>
                ) : (
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-2">
                        {categories.map((cat) => (
                            <button
                                key={cat.id}
                                onClick={() => setSelectedCategory(selectedCategory === cat.title ? null : cat.title)}
                                className={`group relative flex h-24 flex-col items-start justify-between rounded-2xl p-4 border transition-all active:scale-95 overflow-hidden ${selectedCategory === cat.title ? 'bg-primary/20 border-primary' : 'bg-surface-dark border-white/5 hover:border-primary/30'}`}
                            >
                                <div className={`absolute right-[-10px] top-[-10px] h-16 w-16 rounded-full blur-xl transition-all ${selectedCategory === cat.title ? 'bg-primary/30' : 'bg-white/5 group-hover:bg-primary/10'}`}></div>
                                <div className={`rounded-full p-2 ${selectedCategory === cat.title ? 'bg-primary text-background-dark' : 'bg-white/5 text-primary'}`}>
                                    <span className="material-symbols-outlined text-xl">
                                        {cat.title.toLowerCase().includes('sono') ? 'bedtime' :
                                            cat.title.toLowerCase().includes('foco') ? 'center_focus_strong' :
                                                cat.title.toLowerCase().includes('medita') ? 'spa' : 'graphic_eq'}
                                    </span>
                                </div>
                                <span className="text-sm font-bold text-white z-10">{cat.title}</span>
                            </button>
                        ))}
                    </div>
                )}
            </div>

            {/* Track List */}
            <div className="mt-8 flex flex-col px-5">
                <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-bold tracking-tight text-text-light">
                        {selectedCategory ? selectedCategory : (searchQuery ? `Resultados para "${searchQuery}"` : 'Todas as Frequências')}
                    </h3>
                    {selectedCategory && (
                        <span onClick={() => setSelectedCategory(null)} className="text-xs font-semibold text-primary uppercase tracking-wider cursor-pointer hover:underline">Limpar Filtro</span>
                    )}
                </div>

                <div className="flex flex-col gap-3">
                    {filteredTracks.length > 0 ? (
                        filteredTracks.map((track) => {
                            const isCurrent = currentTrack?.id === track.id;
                            return (
                                <div
                                    key={track.id}
                                    onClick={() => playTrack(track)}
                                    className={`group flex items-center gap-3 rounded-2xl p-2.5 transition-all border cursor-pointer ${isCurrent ? 'bg-white/10 border-primary/30' : 'bg-surface-dark/50 hover:bg-surface-dark border-transparent hover:border-white/5'}`}
                                >
                                    <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-surface-darker">
                                        <img className={`absolute inset-0 w-full h-full object-cover transition-opacity ${isCurrent ? 'opacity-40' : 'opacity-70 group-hover:opacity-100'}`} src={getGoogleDriveDirectLink(track.img)} alt={track.title} />
                                        <div className={`absolute inset-0 flex items-center justify-center transition-opacity ${isCurrent ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                                            <span className="material-symbols-outlined text-white fill-1 text-2xl">
                                                {isCurrent && isPlaying ? 'pause' : 'play_arrow'}
                                            </span>
                                        </div>
                                    </div>
                                    <div className="flex flex-1 flex-col justify-center min-w-0">
                                        <h4 className={`text-sm font-bold leading-tight truncate ${isCurrent ? 'text-primary' : 'text-white'}`}>{track.title}</h4>
                                        <p className="text-xs text-text-muted mt-0.5 truncate">{track.subtitle}</p>
                                    </div>
                                    <div className="flex flex-col items-end gap-1">
                                        {track.hz && <span className="rounded bg-primary/10 px-1.5 py-0.5 text-[9px] font-bold text-primary border border-primary/20">{track.hz}</span>}
                                        <span className="text-[10px] font-medium text-text-muted">{track.duration}</span>
                                    </div>
                                </div>
                            );
                        })
                    ) : (
                        <div className="text-center py-10 text-text-muted text-sm">
                            Nenhuma frequência encontrada.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ExplorePage;