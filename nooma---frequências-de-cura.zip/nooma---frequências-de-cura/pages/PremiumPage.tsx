import React from 'react';
import { useNavigate } from 'react-router-dom';

const PremiumPage: React.FC = () => {
    const navigate = useNavigate();
    return (
        <div className="relative flex min-h-screen w-full flex-col overflow-x-hidden max-w-md mx-auto bg-nebula-gradient pb-20">
            <header className="flex items-center p-4 pt-6 pb-2 justify-between z-10 relative">
                 <button onClick={() => navigate(-1)} className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/5 transition-colors">
                    <span className="material-symbols-outlined text-2xl">close</span>
                </button>
                <h2 className="text-white text-sm font-bold tracking-widest uppercase opacity-90 text-center flex-1 pr-10">Seja Premium</h2>
            </header>
            <main className="flex-1 flex flex-col px-5 pb-8">
                <div className="flex flex-col items-center pt-4 pb-8 text-center relative">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-primary/20 rounded-full blur-[80px] -z-10 pointer-events-none"></div>
                    <div className="mb-6 rounded-2xl overflow-hidden border border-white/5 shadow-2xl shadow-primary/5 w-full aspect-[2/1] relative group">
                        <div className="absolute inset-0 bg-gradient-to-t from-background-dark via-transparent to-transparent z-10"></div>
                        <div className="w-full h-full bg-center bg-cover opacity-80 mix-blend-overlay" style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDPAuHJfyPfH5LWAqh07IycfVgI6BZyiQj56nHxgETdyWwlFZKuqirXMJoj25301IlCwNLJQaRoimu3NqeL6N2b59PoMih_C-ud63obu_VVDJMZ5Ro3-IcOKFMOymRNRQrlMV1VSX3vNZ1gJfmfsFCx9gUZle3UC0AYcGBPn9yCE_542pzlZkK56g-yEJEupGmKcQaHwSECdnt138R1PgR2QwqPCPactIZ_re1U7SMUN9ExfEzx9l2FL6R3PdbMkoa4LnEd3dvLr4I")' }}></div>
                        <div className="absolute bottom-4 left-4 z-20 text-left">
                            <p className="text-xs font-medium text-primary mb-1 uppercase tracking-widest">Nooma +</p>
                            <h1 className="text-white text-2xl font-bold leading-tight tracking-tight">Desbloqueie Seu<br/>Potencial</h1>
                        </div>
                    </div>
                </div>
                
                <div className="grid grid-cols-1 gap-4 mb-10">
                    {[
                        { icon: "cloud_download", title: "Acesso Offline", desc: "Baixe sessões para desconectar onde estiver." },
                        { icon: "all_inclusive", title: "Todas as Frequências", desc: "Acesso total à biblioteca de sons curativos." },
                        { icon: "graphic_eq", title: "Sem Interrupções", desc: "Foco puro para sua mente. Zero anúncios." }
                    ].map((feature, i) => (
                        <div key={i} className="flex items-center gap-4 p-4 rounded-xl bg-surface-glass border border-white/5 backdrop-blur-sm">
                            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-white/5 text-primary shrink-0">
                                <span className="material-symbols-outlined">{feature.icon}</span>
                            </div>
                            <div>
                                <h3 className="text-white font-semibold text-base">{feature.title}</h3>
                                <p className="text-white/50 text-xs leading-relaxed">{feature.desc}</p>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="flex flex-col gap-6">
                    <div className="flex justify-center mb-2">
                        <div className="bg-surface-dark p-1 rounded-full border border-white/10 flex relative w-64">
                            <div className="absolute left-1 top-1 bottom-1 w-[calc(50%-4px)] bg-white/10 rounded-full transition-all duration-300 ease-out translate-x-full bg-primary/20 border border-primary/30 shadow-[0_0_10px_rgba(142,225,210,0.2)]"></div>
                            <button className="relative z-10 flex-1 py-2 text-sm font-medium text-white/60 transition-colors text-center rounded-full hover:text-white">Mensal</button>
                            <button className="relative z-10 flex-1 py-2 text-sm font-medium text-white transition-colors text-center rounded-full">Anual</button>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="relative flex flex-col p-4 rounded-2xl border border-white/5 bg-surface-glass opacity-60 hover:opacity-80 transition-opacity cursor-pointer">
                            <div className="h-4 w-4 rounded-full border border-white/30 mb-4"></div>
                            <span className="text-sm text-white/70 mb-1">Mensal</span>
                            <div className="flex items-baseline gap-1">
                                <span className="text-xl font-bold text-white">R$ 29,90</span>
                                <span className="text-xs text-white/40">/mês</span>
                            </div>
                        </div>
                        <div className="relative flex flex-col p-4 rounded-2xl border border-primary bg-active-card shadow-[0_0_30px_-10px_rgba(142,225,210,0.15)] glow-active cursor-pointer">
                            <div className="absolute -top-3 right-3 bg-primary text-background-dark text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider shadow-lg">
                                -45% OFF
                            </div>
                            <div className="flex items-center justify-center h-4 w-4 rounded-full bg-primary text-background-dark mb-4">
                                <span className="material-symbols-outlined text-[10px] font-bold">check</span>
                            </div>
                            <span className="text-sm text-primary mb-1 font-medium">Anual</span>
                            <div className="flex items-baseline gap-1">
                                <span className="text-xl font-bold text-white">R$ 199,90</span>
                                <span className="text-xs text-white/40">/ano</span>
                            </div>
                            <div className="mt-2 pt-2 border-t border-white/10">
                                <p className="text-[10px] text-primary/80">Apenas R$ 16,65/mês</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-10 flex flex-col gap-4">
                    <button className="w-full bg-primary hover:bg-primary-dark text-background-dark font-bold text-lg py-4 rounded-xl shadow-[0_0_20px_rgba(142,225,210,0.3)] transition-all transform active:scale-[0.98]">
                        Assinar Agora
                    </button>
                    <div className="flex justify-center gap-6">
                        <button className="text-[11px] text-white/40 hover:text-white uppercase tracking-wider transition-colors">Restaurar Compra</button>
                        <button className="text-[11px] text-white/40 hover:text-white uppercase tracking-wider transition-colors">Termos e Privacidade</button>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default PremiumPage;