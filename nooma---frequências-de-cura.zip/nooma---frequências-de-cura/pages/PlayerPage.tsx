import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAudio } from '../context/NoomaAudioContext';
import { getGoogleDriveDirectLink, formatTime } from '../utils';

const PlayerPage: React.FC = () => {
    const navigate = useNavigate();
    const { currentTrack, isPlaying, togglePlay, currentTime, duration, seek, progress } = useAudio();

    if (!currentTrack) {
        // Redirect if no track is selected
        React.useEffect(() => {
            navigate('/');
        }, [navigate]);
        return null;
    }

    const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newTime = (Number(e.target.value) / 100) * duration;
        seek(newTime);
    };

    return (
        <div className="bg-background-dark text-white font-display overflow-hidden select-none h-screen w-full relative flex flex-col justify-between group/design-root max-w-md mx-auto">
            <div className="absolute inset-0 z-0 bg-background-dark">
                <img
                    className={`w-full h-full object-cover opacity-60 mix-blend-screen ${isPlaying ? 'animate-pulse-slow' : ''}`}
                    src={getGoogleDriveDirectLink(currentTrack.img)}
                    alt="Background"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-[#131f1d]/40 via-transparent to-[#131f1d] pointer-events-none"></div>
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#131f1d_100%)] opacity-80 pointer-events-none"></div>
            </div>

            <div className="relative z-20 flex items-center justify-between px-6 pt-14 pb-4">
                <button onClick={() => navigate(-1)} className="flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 rounded-full w-10 h-10 transition-all">
                    <span className="material-symbols-outlined text-[30px]">keyboard_arrow_down</span>
                </button>
                <button className="flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 rounded-full w-10 h-10 transition-all">
                    <span className="material-symbols-outlined text-[24px]">cast</span>
                </button>
            </div>

            <div className="flex-grow flex items-center justify-center"></div>

            <div className="relative z-20 w-full glass-panel rounded-t-[32px] pt-8 pb-10 px-6 flex flex-col gap-6 transform transition-transform duration-500">
                <div className="absolute top-3 left-1/2 -translate-x-1/2 w-10 h-1 bg-white/10 rounded-full"></div>
                <div className="text-center space-y-2 mb-2">
                    <h1 className="text-3xl md:text-4xl font-bold text-white tracking-tight leading-tight">{currentTrack.title}</h1>
                    <div className="flex items-center justify-center gap-2 text-primary/80">
                        {isPlaying && <span className="material-symbols-outlined text-[16px] animate-pulse">graphic_eq</span>}
                        <h2 className="text-sm font-medium tracking-wide uppercase text-[#9bc0b9]">{currentTrack.hz || '432Hz'} • {currentTrack.category || 'Relaxamento'}</h2>
                    </div>
                </div>

                <div className="w-full space-y-4">
                    {/* Visual Waveform Simulation */}
                    <div className="flex items-center justify-center gap-[3px] h-12 w-full px-4 mask-image-linear-gradient">
                        {[3, 5, 8, 4, 6, 3, 10, 12, 8, 5, 3, 6, 4, 9, 5, 2, 7, 3, 6, 4, 2].map((h, i) => (
                            <div
                                key={i}
                                className={`waveform-bar ${isPlaying ? 'bg-primary shadow-[0_0_15px_#8ee1d2]' : 'bg-primary/30'}`}
                                style={{ height: isPlaying ? `${h * 3}px` : '4px' }}
                            ></div>
                        ))}
                    </div>

                    {/* Scrub Bar */}
                    <div className="relative w-full h-6 flex items-center group cursor-pointer">
                        {/* Native Range Input for Interaction */}
                        <input
                            type="range"
                            min="0"
                            max="100"
                            value={progress || 0}
                            onChange={handleSeek}
                            className="absolute z-10 w-full h-full opacity-0 cursor-pointer"
                        />

                        {/* Visual Bar */}
                        <div className="absolute w-full h-[2px] bg-white/10 rounded-full overflow-hidden">
                            <div
                                className="h-full bg-primary shadow-[0_0_10px_#8ee1d2]"
                                style={{ width: `${progress}%` }}
                            ></div>
                        </div>
                        {/* Visual Handle */}
                        <div
                            className="absolute w-4 h-4 bg-primary rounded-full shadow-[0_0_15px_#8ee1d2] transform -translate-x-1/2 transition-transform group-hover:scale-125"
                            style={{ left: `${progress}%` }}
                        ></div>

                        <div className="absolute w-full flex justify-between top-4 text-[11px] font-medium text-white/30 font-mono">
                            <span>{formatTime(currentTime)}</span>
                            <span>{formatTime(duration)}</span>
                        </div>
                    </div>
                </div>

                <div className="flex items-center justify-between mt-6 px-2">
                    <button className="flex flex-col items-center gap-1 group text-white/40 hover:text-primary transition-colors">
                        <span className="material-symbols-outlined text-[26px]">all_inclusive</span>
                        <span className="text-[10px] font-medium tracking-wide uppercase">Repetir</span>
                    </button>
                    <div className="flex items-center gap-8">
                        <button className="text-white/60 hover:text-white transition-colors" onClick={() => seek(Math.max(0, currentTime - 10))}>
                            <span className="material-symbols-outlined text-[36px]">replay_10</span>
                        </button>
                        <button
                            className="relative flex items-center justify-center w-[72px] h-[72px] rounded-full bg-primary text-background-dark glow-button hover:scale-105 transition-all active:scale-95"
                            onClick={togglePlay}
                        >
                            <span className="material-symbols-outlined text-[40px] fill-1">
                                {isPlaying ? 'pause' : 'play_arrow'}
                            </span>
                        </button>
                        <button className="text-white/60 hover:text-white transition-colors" onClick={() => seek(Math.min(duration, currentTime + 10))}>
                            <span className="material-symbols-outlined text-[36px]">forward_10</span>
                        </button>
                    </div>
                    <button className="flex flex-col items-center gap-1 group text-white/40 hover:text-primary transition-colors">
                        <span className="material-symbols-outlined text-[26px]">bedtime</span>
                        <span className="text-[10px] font-medium tracking-wide uppercase">Timer</span>
                    </button>
                </div>
                <div className="h-2 w-full"></div>
            </div>
        </div>
    );
};

export default PlayerPage;